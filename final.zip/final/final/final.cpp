#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* pNext;
};

class Linkedlist
{
public:
    Node* pHead;
    Node* pTail;
    Linkedlist()
    {
        pHead = nullptr;
        pTail = nullptr;
    }
    void insert(Node* pTemp)
    {
        if (pHead == nullptr)
        {
            pHead = pTemp;
            pTail = pTemp;
        }
        else
        {
            pTail->pNext = pTemp;
            pTail = pTemp;
        }
    }
    void displayAll()
    {
        Node* pTrav = pHead;
        while (pTrav != nullptr)
        {
            cout << pTrav->data << " ";
            pTrav = pTrav->pNext;
        }
    }

    int calculate(int v1, int v2)
    {
        Node* start = pHead;
        Node* end = pHead;
        int sum = 0;
        for (Node* cur = pHead; cur; cur->pNext)
        {
            if (cur->data == v1)
            {
                start = cur;
            }
            if (cur->data == v2)
            {
                end = cur;
            }
        }
        if (start != nullptr && end != nullptr)
        {
            for (Node* cur = start; cur != nullptr && cur != end->pNext; cur = cur->pNext)
            {
                sum += cur->data;
            }
        }

        return sum;
    }

};


int main()
{
    Linkedlist l;
    int n;
    cout << "Please enter how many nodes" << endl;
    cin >> n;
    int v;
    Node* pTemp;
    for (int i = 0; i < n; i++)
    {
        pTemp = new Node();
        cin >> v;
        pTemp->data = v;
        l.insert(pTemp);
    }
    l.displayAll();

    int v1, v2;
    cout << "Please enter the values to calculate the sum between" << endl;
    cin >> v1 >> v2;

    int sum = l.calculate(v1, v2);
    cout << "Sum between " << v1 << " and " << v2 << " is: " << sum << endl;


    return 0;
}










